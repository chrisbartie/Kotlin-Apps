package com.varsitycollege.st10033223

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val buttonAddition = findViewById<Button>(R.id.buttonAddition)
        val buttonSubtraction = findViewById<Button>(R.id.buttonSubtraction)
        val buttonMultiply = findViewById<Button>(R.id.buttonMultiply)
        val buttonDivision = findViewById<Button>(R.id.buttonDivision)

        val editTextNumber1 = findViewById<EditText>(R.id.editTextNumber1)
        val editTextNumber2 = findViewById<EditText>(R.id.editTextNumber2)

        val textViewDisplay = findViewById<TextView>(R.id.textViewDisplay)
        val textViewAnswer = findViewById<TextView>(R.id.textViewAnswer)
        var textViewOperation = findViewById<TextView>(R.id.textViewOperation)

        buttonAddition?.setOnClickListener {
          var  inputNumberOne = editTextNumber1.text.toString().toInt()
          var  inputNumberTwo = editTextNumber2.text.toString().toInt()
            /*The IIE, (2022)*/
            val answer: String
            val addition: Number
            addition = (inputNumberOne + inputNumberTwo)

            answer = "${inputNumberOne} + ${inputNumberTwo} = ${addition}"
            textViewOperation.text = answer
        }

        buttonSubtraction?.setOnClickListener {
           var inputNumberOne = editTextNumber1.text.toString().toInt()
           var inputNumberTwo = editTextNumber2.text.toString().toInt()
            /*The IIE, (2022)*/
            val answer: String
            val subtraction: Number
            subtraction = (inputNumberOne - inputNumberTwo)

            answer = "${inputNumberOne} - ${inputNumberTwo} = ${subtraction}"
            textViewOperation.text = answer
        }

        buttonDivision?.setOnClickListener {
            var inputNumberOne = editTextNumber1.text.toString().toInt()
            var inputNumberTwo = editTextNumber2.text.toString().toInt()
            /*The IIE, (2022)*/
            val answer: String
            val division: Number
            division = (inputNumberOne / inputNumberTwo)

            answer = "${inputNumberOne} / ${inputNumberTwo} = ${division}"
            textViewOperation.text = answer
        }

        buttonMultiply?.setOnClickListener {
            var inputNumberOne = editTextNumber1.text.toString().toInt()
            var inputNumberTwo = editTextNumber2.text.toString().toInt()
            /*The IIE, (2022)*/
            val answer: String
            val multiply: Number
            multiply = (inputNumberOne * inputNumberTwo)

            answer = "${inputNumberOne} * ${inputNumberTwo} = ${multiply}"
            textViewOperation.text = answer
        }


/*The IIE.2022.Introduction To Mobile Application Development [IMAD5112 Module Manual]. The Independent Institute of Education: Unpublished.*/


    }
}




